%% Convoluting the SEM Image for comparison with TAM Image
% PSF = 382 nm (FWHM in pixels (38.5) X pixel size in nm (e.g. 9.92 nm))

clc
clear
%Read Image
sem_im = im2double(imread('SEM_S_Crop_Norm.tif'));
% Read PSF
psf = im2double(imread('psf.tif'));
% Convolute the image with PSF
sem_im_bl = real(ifft2(abs(fft2(psf, size(sem_im, 1) , size(sem_im, 2))).*fft2(sem_im)));

sem_im_bl_n = (sem_im_bl - min(min(sem_im_bl)))/(max(max(sem_im_bl))-min(min(sem_im_bl)));

imtool(sem_im_bl_n)

saveastiff(single(sem_im_bl_n), 'SEM_Pb_10K_Crop_Norm_Cut_Conv.tif')

%% Patten Search 






%% form PSF as a disk of radius 3 pixels
h = fspecial('disk',4);
% read image and convert to double for FFT
cam = im2double(imread('cameraman.tif'));
hf = psf2otf(h,size(cam));
cam_blur = real(ifft2(hf.*fft2(cam)));
figure(); imshow(cam_blur)
title('blurred image')
xlabel('(original image courtesy Massachusetts Institute of Technology)')

sigma_u = 10^(-40/20)*abs(1-0);
cam_blur_noise = cam_blur + sigma_u*randn(size(cam_blur));
figure(); imshow(cam_blur_noise)
title('noisy image')

cam_inv = real(ifft2(fft2(cam_blur_noise)./hf));
figure(); imshow(cam_inv)
title('inverse filter restoration')

lf = fft2([0 1 0; 1 -4 1; 0 1 0],256,256);
alpha = 0.001;
cam_inv = real(ifft2(fft2(cam_blur_noise)./hf));
cam_reg = deconvreg(cam_blur_noise,lf,0,alpha, 20);

imtool(cam_reg)
title('regularized filter restoration')

%%
clc
clear
T = 1;
alpha = 0.05;
beta = 0.05;
sizex = 256;
sizey = 256;
H = zeros(sizex, sizey);
for i=1:sizex
    for j = 1:sizey
        H(i, j) = T*sin(pi*(alpha*i + beta*j))/(pi*(alpha*i + beta*j))*...
            exp(-1i*pi*(alpha*i+beta*j));
    end
end

% surf(fftshift(abs(fft2(H2p))))

cam_mo=[]; cam_mo = real(ifft2(H.*fft2(cam)));
imtool(cam_mo)

H2 = []; H2 = fspecial('motion', 20, -45);
H2p = []; H2p = padarray(H2, [(256-16)/2 (256-16)/2]);
imtool(H2p)


%% 
% https://blogs.mathworks.com/steve/2007/08/13/image-deblurring-introduction/
clc
clear
h = fspecial('disk',4);
% Read image and convert to double for FFT
cam = im2double(imread('cameraman.tif'));
hf = fft2(h,size(cam,1),size(cam,2));
cam_blur = real(ifft2(hf.*fft2(cam)));
imtool(cam_blur)

sigma_u = 10^(-40/20)*abs(1-0);
cam_blur_noise = cam_blur + sigma_u*randn(size(cam_blur));
imtool(cam_blur_noise)

cam_inv = real(ifft2(fft2(cam_blur_noise)./hf));
imtool(cam_inv)

hf_abs = abs(hf);
surf([-127:128]/128,[-127:128]/128,fftshift(hf_abs))
shading interp, camlight, colormap jet
xlabel('PSF FFT magnitude')

cam_pinv = real(ifft2((abs(hf) > 0.1).*fft2(cam_blur_noise)./hf));
imtool(cam_pinv)
xlabel('pseudo-inverse restoration')

cam_pinv2 = real(ifft2(fft2(cam_blur_noise).*conj(hf)./(abs(hf).^2 + 8e-3)));
imtool(cam_pinv2)
xlabel('alternative pseudo-inverse restoration')


%% Motion Blur Correction
clc
clear

im_bl = im2double(imread('20181226_1309ave.tif'));
% mo_bl = fspecial('motion', 8, 90);
% mo_bl = zeros(512, 512);
% mo_bl(256-4:256+4, 256) = 3*normpdf(-4:4, 0, 5); 
% mo_bl(256-4:256+4, 256) = fspecial('motion', 8, 90);
mo_bl = 3*normpdf(-4:4, 0, 8)';
mo_bl_f = fftshift(fft2(mo_bl, 512, 512)); 
mo_bl2 = real(ifft2(mo_bl_f));

im = real(ifft2(fft2(im_bl).*conj(mo_bl_f)./(abs(mo_bl_f).^2 + 0.5)));

im2 = im;
for i = 1:3
    im2 = real(ifft2(fft2(im2).*conj(mo_bl_f)./(abs(mo_bl_f).^2 + 0.1)));
%     im2 = real(ifft2((abs(mo_bl_f) > 1).*fft2(im2)./mo_bl_f));

end 
% im = real(ifft2((abs(mo_bl_f) > 0.1).*fft2(im_bl)./mo_bl_f));
% im2 = real(ifft2((abs(mo_bl_f) > 0.1).*fft2(im)./mo_bl_f));

imtool(im_bl)
% figure('Name', 'im_bl');histogram(im_bl)
imtool(im)
% figure('Name', 'im'); histogram(im)
imtool(im2)


